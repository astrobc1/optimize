.. _installation:

Installation
************

It is recommended the user installs from GitHub.

From PyPI
=========



From GitHub
===========

Download with

``git clone https://github.com/astrobc1/optimize``

Change directories into the head optimize directory, and install with

``pip install .``